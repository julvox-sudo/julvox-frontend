# ============================================================
#  DealScan v5 — Base de données
#  CORRECTIFS v5.1 :
#  ✅ Garde SQLite-en-production : crash explicite au démarrage
#     plutôt que corruption silencieuse des données
#  ✅ get_db_context() : contextmanager sûr pour le cron
#     (session TOUJOURS fermée même en cas d'exception)
#  ✅ Nettoyage automatique du rate_limit_store toutes les 10 min
#     pour éviter la fuite mémoire sous charge
# ============================================================

import os
import time
import logging
import threading
from contextlib import contextmanager

from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger("dealscan.db")

# ── Sélection automatique de la base ─────────────────────────
_raw_url = os.getenv("DATABASE_URL", "")

if _raw_url:
    # Railway fournit parfois postgres:// au lieu de postgresql://
    DATABASE_URL = _raw_url.replace("postgres://", "postgresql://", 1)
    logger.info(f"🗄️  DB: {'PostgreSQL' if 'postgresql' in DATABASE_URL else 'SQLite custom'}")

elif os.path.isdir("/data"):
    DATABASE_URL = "sqlite:////data/dealscan.db"
    logger.info("🗄️  DB: SQLite sur volume Railway /data")
    os.makedirs("/data", exist_ok=True)

else:
    DATABASE_URL = "sqlite:///./dealscan.db"
    logger.info("🗄️  DB: SQLite local (développement)")

# ── CORRECTIF 1 : Bloquer SQLite en production ───────────────
# Si Railway détecte l'env RAILWAY_ENVIRONMENT et qu'on est sur
# SQLite → crash explicite au démarrage avec message clair.
# Bien mieux qu'un crash silencieux "database is locked" plus tard.
if os.getenv("RAILWAY_ENVIRONMENT") and DATABASE_URL.startswith("sqlite"):
    raise RuntimeError(
        "\n\n❌ ERREUR CRITIQUE : SQLite détecté en production Railway !\n"
        "SQLite ne supporte pas la concurrence — ton site crashera.\n\n"
        "Solution (2 minutes) :\n"
        "  Railway → ton projet → New → Database → Add PostgreSQL\n"
        "  Puis copie l'URL dans : Variables → DATABASE_URL\n"
        "  Format : postgresql://user:pass@host:5432/railway\n"
    )

# ── Configuration engine ──────────────────────────────────────
is_sqlite = DATABASE_URL.startswith("sqlite")

connect_args = {"check_same_thread": False} if is_sqlite else {
    "connect_timeout": 10,
    "options": "-c statement_timeout=30000",  # 30s max par requête
}

engine_kwargs = {
    "connect_args": connect_args,
    "echo": False,
}

if not is_sqlite:
    engine_kwargs.update({
        "pool_size": 5,
        "max_overflow": 10,
        "pool_pre_ping": True,    # Vérifier que la connexion est vivante
        "pool_recycle": 300,      # Recycler les connexions toutes les 5 min
    })
else:
    engine_kwargs["connect_args"]["timeout"] = 20

engine       = create_engine(DATABASE_URL, **engine_kwargs)
SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)


def init_db():
    """Crée toutes les tables et tous les index si inexistants."""
    from models import Base
    Base.metadata.create_all(bind=engine)

    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        logger.info("✅ Base de données initialisée et opérationnelle")
    except Exception as e:
        logger.error(f"❌ Erreur DB au démarrage: {e}")
        raise

    _seed_demo_data()


# ── CORRECTIF 2 : get_db() pour FastAPI (inchangé) ───────────
def get_db():
    """Dependency FastAPI — session par requête HTTP."""
    db = SessionLocal()
    try:
        yield db
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


# ── CORRECTIF 2 (suite) : get_db_context() pour le CRON ──────
@contextmanager
def get_db_context():
    """
    Context manager sûr pour une utilisation en dehors de FastAPI.
    À utiliser dans le cron runner et les tâches background.

    Utilisation :
        with get_db_context() as db:
            deals = db.query(Deal).filter(...).all()
        # La session est TOUJOURS fermée ici, même en cas d'exception.

    Ne jamais utiliser next(get_db()) dans le cron —
    la session ne serait pas fermée si une exception survient.
    """
    db = SessionLocal()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()  # TOUJOURS exécuté


# ── CORRECTIF 3 : Nettoyage du rate_limit_store ──────────────
# Le dict _rate_limit_store dans auth.py grossit indéfiniment
# sans nettoyage (une entrée par IP × endpoint).
# Cette fonction tourne en daemon thread toutes les 10 minutes
# et supprime les entrées inactives depuis plus d'1 heure.
def start_rate_limit_cleanup():
    """
    À appeler UNE FOIS dans le lifespan de l'app :
        from db import start_rate_limit_cleanup
        start_rate_limit_cleanup()
    """
    def _cleanup_loop():
        # Import ici pour éviter une dépendance circulaire au chargement
        from auth import _rate_limit_store

        while True:
            time.sleep(600)  # Toutes les 10 minutes
            now = time.time()
            keys_to_delete = []

            for key, timestamps in list(_rate_limit_store.items()):
                # Garder seulement les entrées de la dernière heure
                active = [t for t in timestamps if now - t < 3600]
                if not active:
                    keys_to_delete.append(key)
                else:
                    _rate_limit_store[key] = active

            for k in keys_to_delete:
                _rate_limit_store.pop(k, None)

            if keys_to_delete:
                logger.info(
                    f"🧹 Rate limit store nettoyé : "
                    f"{len(keys_to_delete)} entrées supprimées, "
                    f"{len(_rate_limit_store)} restantes"
                )

    t = threading.Thread(target=_cleanup_loop, daemon=True, name="rate-limit-cleanup")
    t.start()
    logger.info("✅ Nettoyage rate limit store démarré (toutes les 10 min)")


# ── Données de démo ───────────────────────────────────────────
def _seed_demo_data():
    """Insère des données de démo au premier lancement uniquement."""
    from models import Product, Deal, PriceHistory
    from datetime import datetime, timedelta
    import random

    with get_db_context() as db:
        if db.query(Product).count() > 0:
            return  # Déjà initialisé

        logger.info("🌱 Insertion des données de démo...")

        demo_products = [
            {"name": 'MacBook Air M3 13" 16Go/512Go', "brand": "Apple",     "category": "high-tech",   "image_url": "💻"},
            {"name": "Samsung Galaxy S25 Ultra 256Go",  "brand": "Samsung",   "category": "high-tech",   "image_url": "📱"},
            {"name": "Sony WH-1000XM5",                 "brand": "Sony",      "category": "high-tech",   "image_url": "🎧"},
            {"name": "PS5 Slim + 2 manettes",            "brand": "Sony",      "category": "gaming",      "image_url": "🎮"},
            {"name": 'LG OLED 65" C3',                  "brand": "LG",        "category": "high-tech",   "image_url": "📺"},
            {"name": "Nike Air Max 270",                 "brand": "Nike",      "category": "mode",        "image_url": "👟"},
            {"name": "Adidas Stan Smith",                "brand": "Adidas",    "category": "mode",        "image_url": "👟"},
            {"name": "Levi's 501 Original",              "brand": "Levi's",    "category": "mode",        "image_url": "👖"},
            {"name": "Lait Lactel 6×1L",                "brand": "Lactel",    "category": "alimentaire", "image_url": "🥛"},
            {"name": "Saumon fumé Label Rouge 200g",    "brand": "Labeyrie",  "category": "alimentaire", "image_url": "🐟"},
            {"name": "Café Nespresso Capsules ×50",     "brand": "Nespresso", "category": "alimentaire", "image_url": "☕"},
            {"name": "Canapé convertible 3 places",     "brand": "IKEA",      "category": "maison",      "image_url": "🛋️"},
            {"name": "Robot Aspirateur Roomba i7",      "brand": "iRobot",    "category": "maison",      "image_url": "🤖"},
        ]

        stores_by_cat = {
            "high-tech":   ["Amazon.fr", "Fnac.com", "Darty.com", "Boulanger.com"],
            "gaming":      ["Amazon.fr", "Fnac.com", "Cdiscount.com"],
            "mode":        ["Zalando.fr", "Nike.com", "Amazon.fr"],
            "alimentaire": ["Carrefour", "Leclerc", "Lidl.fr"],
            "maison":      ["IKEA.com", "Amazon.fr", "Conforama.fr"],
        }

        for p_data in demo_products:
            p = Product(**p_data)
            db.add(p)
            db.flush()

            cat   = p_data["category"]
            store = random.choice(stores_by_cat.get(cat, ["Amazon.fr"]))

            base_price = random.uniform(15, 1500)
            history    = []
            price      = base_price * 1.2

            for day in range(90, 0, -1):
                price += random.uniform(-price * 0.05, price * 0.04)
                price  = max(base_price * 0.5, price)
                h = PriceHistory(
                    product_id  = p.id,
                    store       = store,
                    price       = round(price, 2),
                    recorded_at = datetime.utcnow() - timedelta(days=day),
                )
                db.add(h)
                history.append(price)

            current_price  = round(min(history) * random.uniform(1.0, 1.15), 2)
            original_price = round(max(history) * random.uniform(0.95, 1.0), 2)
            discount_pct   = round((original_price - current_price) / original_price * 100, 1)
            score          = _calculate_score_simple(current_price, history)

            deal = Deal(
                product_id     = p.id,
                store          = store,
                current_price  = current_price,
                original_price = original_price,
                discount_pct   = max(0, discount_pct),
                novadeal_score = score,
                is_fake        = False,
                affiliate_url  = f"https://julvox.com/?deal=demo_{p.id}",
                expires_at     = datetime.utcnow() + timedelta(hours=random.randint(2, 72)),
            )
            db.add(deal)

        logger.info(f"✅ {len(demo_products)} produits de démo insérés")


def _calculate_score_simple(current_price: float, history: list) -> float:
    """Score simplifié pour les données de démo."""
    if not history:
        return 50.0
    median = sorted(history)[len(history) // 2]
    if median <= 0:
        return 50.0
    disc = (median - current_price) / median
    return round(min(100.0, max(0.0, 50 + disc * 100)), 1)
