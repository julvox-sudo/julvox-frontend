# ============================================================
#  DealScan v5 — Patch main.py (2 modifications)
#  À appliquer dans ton main.py existant
# ============================================================

# ────────────────────────────────────────────────────────────
#  MODIFICATION 1 — Lifespan : activer le nettoyage mémoire
#  Trouve ce bloc dans main.py et remplace-le par celui-ci :
# ────────────────────────────────────────────────────────────

# AVANT :
# @asynccontextmanager
# async def lifespan(app: FastAPI):
#     logger.info("🚀 DealScan v5 API démarrée — NovaDeal™ v2 — Sécurité activée")
#     init_db()
#     _seed_demo_deals()
#     import asyncio
#     asyncio.get_event_loop().create_task(_cron_runner())
#     yield

# APRÈS (ajouter les 2 lignes marquées ✅) :
# @asynccontextmanager
# async def lifespan(app: FastAPI):
#     logger.info("🚀 DealScan v5 API démarrée — NovaDeal™ v2 — Sécurité activée")
#     init_db()
#     _seed_demo_deals()
#     from db import start_rate_limit_cleanup   # ✅ AJOUTER
#     start_rate_limit_cleanup()                # ✅ AJOUTER
#     import asyncio
#     asyncio.get_event_loop().create_task(_cron_runner())
#     yield


# ────────────────────────────────────────────────────────────
#  MODIFICATION 2 — Cron runner : utiliser get_db_context()
#  Trouve les 2 blocs "db = next(get_db())" dans _cron_runner
#  et remplace-les par la version sûre ci-dessous :
# ────────────────────────────────────────────────────────────

# AVANT (bloc alertes) :
# db = next(get_db())
# alerts = db.query(PriceAlert).filter(PriceAlert.is_active == True).all()
# ...
# db.close()   ← jamais appelé si exception !

# APRÈS :
# from db import get_db_context
# with get_db_context() as db:
#     alerts = db.query(Alert).filter(Alert.is_active == True).all()
#     sent = 0
#     for alert in alerts:
#         try:
#             deal = db.query(Deal).filter(
#                 Deal.product_id == alert.product_id,
#                 Deal.current_price <= alert.target_price,
#                 Deal.is_active == True
#             ).first()
#             if deal:
#                 from email_service import send_price_alert_email
#                 user = db.query(User).filter(User.id == alert.user_id).first()
#                 if user and user.email:
#                     await send_price_alert_email(user.email, deal, alert.target_price)
#                     sent += 1
#         except Exception:
#             pass
#     if sent > 0:
#         logger.info(f"📧 {sent} alertes email envoyées")
# # ← session fermée automatiquement ici


# AVANT (bloc scraping) :
# db = next(get_db())
# count = run_all_scrapers(db)
# logger.info(f"🔍 Scraping: {count} deals mis à jour")
# db.close()   ← jamais appelé si exception !

# APRÈS :
# from db import get_db_context
# with get_db_context() as db:
#     count = run_all_scrapers(db)
#     logger.info(f"🔍 Scraping: {count} deals mis à jour")
# # ← session fermée automatiquement ici
