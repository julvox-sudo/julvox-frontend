# ============================================================
#  DealScan v5 — Modèles de base de données
#  CORRECTIFS v5.1 :
#  ✅ Index ajoutés sur toutes les colonnes filtrées
#     → performances ×10 à ×100 sous charge
# ============================================================

from sqlalchemy import (
    Column, Integer, String, Float, DateTime,
    Boolean, ForeignKey, Text, Index,
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime

Base = declarative_base()


class Product(Base):
    __tablename__ = "products"
    id         = Column(Integer, primary_key=True, index=True)
    name       = Column(String, nullable=False)
    brand      = Column(String, default="")
    category   = Column(String, default="")
    ean        = Column(String, unique=True, nullable=True)
    image_url  = Column(String, default="")
    created_at = Column(DateTime, default=datetime.utcnow)
    prices     = relationship("PriceHistory", back_populates="product")
    deals      = relationship("Deal",         back_populates="product")


class PriceHistory(Base):
    __tablename__ = "price_history"
    id          = Column(Integer, primary_key=True, index=True)
    product_id  = Column(Integer, ForeignKey("products.id"), nullable=False)
    store       = Column(String,  nullable=False)
    price       = Column(Float,   nullable=False)
    url         = Column(String,  default="")
    recorded_at = Column(DateTime, default=datetime.utcnow)
    product     = relationship("Product", back_populates="prices")

# ── Index PriceHistory ──────────────────────────────────────
# Requête la plus fréquente : historique d'un produit trié par date
Index("ix_price_history_product_date",
      PriceHistory.product_id,
      PriceHistory.recorded_at)


class Deal(Base):
    __tablename__ = "deals"
    id             = Column(Integer, primary_key=True, index=True)
    product_id     = Column(Integer, ForeignKey("products.id"))
    store          = Column(String,  nullable=False)
    current_price  = Column(Float,   nullable=False)
    original_price = Column(Float)
    discount_pct   = Column(Float)
    novadeal_score = Column(Float)
    is_fake        = Column(Boolean, default=False)
    affiliate_url  = Column(String,  default="")
    expires_at     = Column(DateTime, nullable=True)
    detected_at    = Column(DateTime, default=datetime.utcnow)
    is_active      = Column(Boolean, default=True)
    product        = relationship("Product", back_populates="deals")

# ── Index Deal ──────────────────────────────────────────────
# Requête home page : deals actifs triés par score
Index("ix_deals_active_score",
      Deal.is_active,
      Deal.novadeal_score)

# Requête fiche produit : tous les deals d'un produit
Index("ix_deals_product_id",
      Deal.product_id)

# Requête filtrage par store
Index("ix_deals_active_store",
      Deal.is_active,
      Deal.store)


class Alert(Base):
    __tablename__ = "alerts"
    id           = Column(Integer, primary_key=True, index=True)
    user_id      = Column(String,  nullable=False)
    product_name = Column(String,  nullable=False)
    target_price = Column(Float,   nullable=True)
    category     = Column(String,  nullable=True)
    min_score    = Column(Float,   default=75)
    is_active    = Column(Boolean, default=True)
    created_at   = Column(DateTime, default=datetime.utcnow)
    triggered_at = Column(DateTime, nullable=True)

# ── Index Alert ─────────────────────────────────────────────
# Cron job : toutes les alertes actives d'un utilisateur
Index("ix_alerts_user_active",
      Alert.user_id,
      Alert.is_active)


class User(Base):
    """Utilisateur DealScan — statut premium géré CÔTÉ SERVEUR uniquement."""
    __tablename__ = "users"
    id             = Column(Integer, primary_key=True, index=True)
    firebase_uid   = Column(String,  unique=True, nullable=False)
    email          = Column(String,  default="")
    is_pro         = Column(Boolean, default=False)
    is_owner       = Column(Boolean, default=False)   # Toi seul = True
    pro_expires_at = Column(DateTime, nullable=True)  # Null = gratuit ou owner
    created_at     = Column(DateTime, default=datetime.utcnow)
    last_seen      = Column(DateTime, default=datetime.utcnow)
    login_count    = Column(Integer,  default=0)
    is_banned      = Column(Boolean,  default=False)
    ban_reason     = Column(String,   nullable=True)

# ── Index User ──────────────────────────────────────────────
Index("ix_users_firebase_uid",
      User.firebase_uid)


class PromoCode(Base):
    """Codes promo vérifiés automatiquement."""
    __tablename__ = "promo_codes"
    id            = Column(Integer, primary_key=True, index=True)
    code          = Column(String,  nullable=False)
    store         = Column(String,  nullable=False)
    category      = Column(String,  default="")
    discount_desc = Column(String,  default="")
    min_order     = Column(Float,   default=0)
    is_verified   = Column(Boolean, default=False)
    success_rate  = Column(Float,   default=0)
    expires_at    = Column(DateTime, nullable=True)
    last_tested   = Column(DateTime, default=datetime.utcnow)
    created_at    = Column(DateTime, default=datetime.utcnow)


class AuditLog(Base):
    """Log de toutes les actions sensibles."""
    __tablename__ = "audit_logs"
    id         = Column(Integer, primary_key=True, index=True)
    action     = Column(String,  nullable=False)
    user_id    = Column(String,  nullable=True)
    ip_address = Column(String,  nullable=True)
    details    = Column(Text,    default="{}")
    created_at = Column(DateTime, default=datetime.utcnow)
